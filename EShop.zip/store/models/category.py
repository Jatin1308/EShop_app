from django.db import models

class Category(models.Model):
	name = models.CharField(max_length=20)


	@staticmethod
	def get_all_categories():
		return Category.objects.all()



	def __str__(self):
		return self.name     # for showing the category name in the product table 
							# str method outputs all the members of the class