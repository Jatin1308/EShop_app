from django.shortcuts import render, redirect
from django.http import HttpResponse
from store.models.product import Product
from store.models.category import Category
from store.models.customer import Customer
from store.models.orders import Order
from django.views import View

from store.middlewares.auth import auth_middleware





class OrderView(View):

	# @method_decorator(auth_middleware)     # cannot use directlyt the decorator here because it is method not  a function
	def get(self,request):
		customer = request.session.get('customer_id')
		orders = Order.get_orders_by_customers(customer)
		return render(request, 'orders.html', {'orders':orders})