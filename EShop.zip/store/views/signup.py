from django.shortcuts import render, redirect
from store.models.customer import Customer   # .models.customer :- folder named - model and file in it named customer, this file has class Customer
from django.views import View
import re





class Signup(View):

	def get(self,request):
		return render(request,'signup.html')
	def post(self, request):
		postData = request.POST
		first_name = postData.get('firstname')
		last_name = postData.get('lastname')
		phone = postData.get('phone')
		email = postData.get('email')
		password = postData.get('password')
		value = {
				'first_name':first_name,
				'last_name':last_name,
				'phone': phone,
				'email': email
			}
		customer = Customer(first_name=first_name,last_name=last_name,phone=phone,email=email,password=password)
		error_message = self.validateCustomer(customer)
		if not error_message:
			customer.password = make_password(customer.password)			
			customer.register() 
			return redirect('homepage')
		else:
			data = {
			'error':error_message,
			'values': value      # prevent the form reload if wrong format entered for certain fields
			}
			return render(request, 'signup.html',data )
	def validateCustomer(self,customer):
		error_message = None
		regex_email = '^[a-z0-9_]{5,}\@+(gmail|yahoo|rediffmail)+\.(com|gov.in|co.in)$'
		first_name = customer.first_name
		last_name = customer.last_name
		email = customer.email
		phone = customer.phone
		password = customer.password
		if not password or not first_name or not last_name or not email or not phone:
			error_message = "All fields are compulsory"
		elif len(first_name)>20 or len(last_name)>20 or len(email)>50 or len(phone)>13 or len(password)<6:
			error_message = "Invalid Length of some fields"
		elif re.search(regex_email,email) == None:
			error_message = "Invalid Email"
		elif customer.is_exist():
			error_message = "Email already registered"

		return error_message